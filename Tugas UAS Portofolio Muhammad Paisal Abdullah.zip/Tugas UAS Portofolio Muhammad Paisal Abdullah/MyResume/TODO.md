# TODO List for Updating Hero Social Icons

- [x] Update hero social links to only include Instagram, GitHub, and WhatsApp
- [x] Test the hero section to ensure icons display correctly
